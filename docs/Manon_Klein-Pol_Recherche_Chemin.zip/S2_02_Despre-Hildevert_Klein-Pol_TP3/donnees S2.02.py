"""
IUT de Bayonne et du Pays Basque
Département Informatique
BUT Informatique Semestre 2 2023-2024

S2.02 - Exploration algorithmique d'un problème
Etape 3 : visualisation à l'aide d'une bibliothèque graphique

Manon Klein-Pol
Léa Despre-Hildevert
TP3

07/06/2024
"""

import json
import pandas as pd
import numpy as np
import os
import time

from graphics import GraphWin
from graphics import Image
from graphics import Point

# à modifier si besoin
os.chdir('C:/Users/anaki/Dropbox/My PC (DESKTOP-BEGB6E7)/Downloads/S2_02_Despre-Hildevert_Klein-Pol_TP3')

# import dicsucc.json et dicsuccdist.json (--> dictionnaire)
with open("dicsucc.json", "r") as fichier:
    dicsucc = json.load(fichier)
with open("dicsuccdist.json", "r") as fichier:
    dicsuccdist = json.load(fichier)

# import aretes.csv (--> dataframe) et transformation de lstpoints (chaîne-->liste)
aretes = pd.read_table('aretes.csv', sep=';', index_col=0)

for ind in aretes.index:
    ls = aretes.loc[ind, 'lstpoints'].replace(
        " ", "").replace("]", "").replace("[", "").split(',')
    lst = []
    for val in ls:
        lst.append(int(val))
    aretes.at[ind, 'lstpoints'] = lst


# import sommets.csv, matrice_poids.csv (--> dataframe)
sommets = pd.read_table('sommets.csv', sep=';', index_col=0)
matrice_poids = pd.read_csv('matrice_poids.csv', sep=';', index_col=0)

# transformation dataframe matrice des poids en tableau
tableau_poids = np.array(matrice_poids)

# transformation matrice des poids en liste de listes
liste_poids = [[None for j in range(len(tableau_poids))]
                                    for i in range(len(tableau_poids))]
for i in range(len(tableau_poids)):
    for j in range(len(tableau_poids)):
        liste_poids[i][j] = tableau_poids[i, j]


del fichier, i, j, val, ls, lst, ind


"""
_________________________________


             ETAPE 2
          
_________________________________

"""

# Réinitialiser l'index du DataFrame sommets pour avoir des indices de 0 à len(sommets)-1
sommets = sommets.reset_index()


# Trouver les sommets de départ et d'arrivée des arcs

# Créer les deux colonnes arrivee et depart
aretes['depart'] = None
aretes['arrivee'] = None

# Créer une liste pour stocker les identifiants des sommets
lst_sommets = []

# Parcourir les indices des lignes de aretes
for ind in aretes.index:

    # Récupérer la liste des points
    ens_points = aretes.loc[ind, 'lstpoints']

    # Ajouter les sommets de départ et d'arrivée à la liste des sommets
    lst_sommets.append(ens_points[0])
    lst_sommets.append(ens_points[-1])

    # Mettre les sommets de départ et d'arrivée dans aretes
    aretes.loc[ind, "depart"] = ens_points[0]
    aretes.loc[ind, "arrivee"] = ens_points[-1]

# Encodage des sommets de départ et d'arrivée
aretes["depart"] = aretes["depart"].astype('int64')
aretes["arrivee"] = aretes["arrivee"].astype('int64')


# Fonction pour convertir un nom de sommet en indice
def indice(som):
    
    # Recherche de l'indice à partir de la colonne 'id_point' du DataFrame sommets
    return sommets[sommets['id_point'] == som].index[0]

# Fonction pour convertir un indice en nom de sommet
def nomsom(indice):
    
    # Récupération de la valeur de la colonne 'id_point' à partir de l'indice du DataFrame sommets
    return sommets.loc[indice, 'id_point']

# Fonction pour extraire le nœud avec la plus petite distance dans une liste de distances
def extract_min(dist, atraiter):
    min_dist = float('inf')  # Initialiser la distance minimale à l'infini
    min_noeud = None  # Initialiser le nœud avec la distance minimale à None
    for noeud in atraiter:  # Parcourir tous les nœuds à traiter
        # Si la distance du nœud actuel est plus petite que la distance minimale
        if dist[noeud] <= min_dist:
            min_dist = dist[noeud]  # Mettre à jour la distance minimale
            min_noeud = noeud  # Mettre à jour le nœud avec la distance minimale
    return min_noeud  # Retourner le nœud avec la distance minimale

# Fonction pour reconstruire le chemin le plus court à partir de la liste des prédécesseurs
def reconstitution(pred, dep, arr):
    # Convertir les sommets de départ et d'arrivée en indices
    dep = indice(dep)
    arr = indice(arr)

    # Ajouter le nom de sommet correspondant à l'arrivée initiale
    chemin = [nomsom(arr)]
    while arr != dep:  # Tant que le nœud actuel n'est pas le nœud de départ
        pred_arr = pred[arr]  # Sauvegarder le prédécesseur actuel
        arr = pred_arr  # Mettre à jour le nœud actuel avec son prédécesseur
        chemin.append(nomsom(arr))  # Ajouter le nom du nœud actuel au chemin

    # Inverser le chemin pour qu'il aille du départ à l'arrivée
    return chemin[::-1]

# Fonction pour relâcher un arc et mettre à jour les distances et les prédécesseurs si un chemin plus court est trouvé
def relacher(u, v, dist, pred):
    if dist[v] > dist[u] + liste_poids[u][v]:  # Si la distance de v est plus grande que la distance de u + le poids de l'arc (u, v)
        dist[v] = dist[u] + liste_poids[u][v]  # Mettre à jour la distance de v
        pred[v] = u  # Mettre à jour le prédécesseur de v avec u


dic = {}
for som in dicsucc:
    dic[int(som)] = dicsucc[som]
dicsucc = dic

dic = {}
for som in dicsuccdist:
    dic[int(som)] = dicsuccdist[som]
dicsuccdist = dic


"""
Liste h: Contient les valeurs heuristiques pour chaque sommet.
Liste f: Contient les valeurs de F=G+H pour chaque sommet.
Fonction extract_min: Sélectionne le nœud avec la plus petite valeur devF.
Fonction relacher: Met à jour les distances et les valeurs debF.
"""

# Fonction pour extraire le nœud avec la plus petite valeur de F = G + H dans une liste de distances
def extract_min_A(f, atraiter):
    min_f = float('inf')
    min_noeud = None
    for noeud in atraiter:
        if f[noeud] <= min_f:
            min_f = f[noeud]
            min_noeud = noeud
    return min_noeud

# Fonction heuristique pour estimer la distance restante (utilisation de la distance de Manhattan)
def heuristique(a, b):
    coord_a = sommets.loc[a, ['lat', 'lon']]
    coord_b = sommets.loc[b, ['lat', 'lon']]
    return abs(coord_a['lat'] - coord_b['lon']) + abs(coord_a['lon'] - coord_b['lon'])

# Fonction pour relâcher un arc et mettre à jour les distances et les prédécesseurs si un chemin plus court est trouvé
def relacher_A(u, v, dist, pred, f, h):
    if dist[v] > dist[u] + liste_poids[u][v]:
        dist[v] = dist[u] + liste_poids[u][v]
        pred[v] = u
        f[v] = dist[v] + h[v]



"""
_________________________________


             ETAPE 3
          
_________________________________

"""

# Conversion des coordonnées GPS en coordonnées d'image

# Dimensions de la fenêtre
largeur = 1411
hauteur = 912

# Définir les coordonnées GPS extrêmes
lat_min, lat_max = 43.48478, 43.4990
lon_min, lon_max = -1.48768, -1.45738

# Créer les colonnes x et y
sommets['x'] = None
sommets['y'] = None

# Conversion des coordonnées GPS en coordonnées d'image
for ind in sommets.index:
    # Convertir la latitude et la longitude en coordonnées de la carte et les mettre dans le dataframe
    sommets.loc[ind, "x"] = (sommets.loc[ind, "lon"] - lon_min) / (lon_max - lon_min) * largeur
    sommets.loc[ind, "y"] = hauteur - (sommets.loc[ind, "lat"] - lat_min) / (lat_max - lat_min) * hauteur
    
    
"""
_________________________________

          Dijkstra
_________________________________

"""

def Dijkstra(dep, arriv,fen):
    n = len(liste_poids)  # Nombre de sommets
    depart = indice(dep)  # Indice du sommet de départ
    arrivee = indice(arriv)  # Indice du sommet d'arrivée

    dist = [float('inf')] * n  # Initialisation des distances à l'infini
    pred = [None] * n
    # Initialisation pour suivre les sommets traités
    atraiter = [i for i in range(n)]

    dist[depart] = 0  # Distance du sommet de départ à lui-même est 0

    # Boucle principale de l'algorithme
    while atraiter:
        # Sélectionner le sommet non traité avec la plus petite distance
        u = extract_min(dist, atraiter)

        atraiter.remove(u)  # Enlever le sommet à traiter

        if nomsom(u) == arrivee:
            break
        
        # Mettre à jour les distances pour les sommets adjacents non traités
        for v in atraiter:
                
                relacher(u, v, dist, pred)
                
                # Trouver les indices des arcs d'arrivée "v" dans le DataFrame aretes
                indices_arc_arrivee_v = aretes.index[aretes['arrivee'] == nomsom(v)].tolist()
                
                
                for ind in indices_arc_arrivee_v:
                    # Récupérer le sommet de départ de l'arc à partir de l'indice trouvé
                    sommet_depart = aretes.loc[ind, 'depart']
            
                    point_debut = Point(sommets.loc[indice(sommet_depart), "x"], sommets.loc[indice(sommet_depart), "y"])
                    point_fin = Point(sommets.loc[v, "x"], sommets.loc[v, "y"])
                    
                    #Tracer l'arc traité
                    arc = fen.create_line(point_debut.x, point_debut.y, point_fin.x, point_fin.y, fill="red", width=2)
            
                    
                # Attendre un court moment
                time.sleep(0.1)
    
                fen.update()
                
    # Reconstitution du chemin le plus court
    chemin = reconstitution(pred, dep, arriv)
    
    
    return dist[arrivee], chemin


"""
_________________________________

          Bellman
_________________________________

"""

def Bellman(dep, arriv,fen):
    n = len(dicsucc)  # Nombre de sommets
    depart = indice(dep)  # Indice du sommet de départ
    arrivee = indice(arriv)  # Indice du sommet d'arrivée

    dist = [float('inf')] * n  # Initialisation des distances à l'infini
    pred = [None] * n
    dist[depart] = 0  # Distance du sommet de départ à lui-même est 0

    # Relaxation des arcs pour n-1 itérations
    for i in range(n - 1):
        change = False  # Détection de l'invariance

        for som in dicsuccdist:
            u = indice(som)
            for [succ, d] in dicsuccdist[som]:
                v = indice(succ)
                # Relachement
                if dist[v] > dist[u] + d:
                    dist[v] = dist[u] + d
                    pred[v] = u
                    change = True
                    
                    
                    # Trouver les indices des arcs d'arrivée "v" dans le DataFrame aretes
                    indices_arc_arrivee_v = aretes.index[aretes['arrivee'] == nomsom(v)].tolist()
                    
                    #if indices_arc_arrivee_v:  # Vérifier si la liste n'est pas vide
                    
                    for ind in indices_arc_arrivee_v:
                        # Récupérer le sommet de départ de l'arc à partir de l'indice trouvé
                        sommet_depart = aretes.loc[ind, 'depart']
                
                        point_debut = Point(sommets.loc[indice(sommet_depart), "x"], sommets.loc[indice(sommet_depart), "y"])
                        point_fin = Point(sommets.loc[v, "x"], sommets.loc[v, "y"])
                        
                        #Tracer l'arc traité
                        arc = fen.create_line(point_debut.x, point_debut.y, point_fin.x, point_fin.y, fill="red", width=2)
                
                        
                    # Attendre un court moment
                    time.sleep(0.1)
        
                    fen.update()
                    
                    
        if not change:  # Si aucune mise à jour, terminer
            break

    # Reconstitution du chemin le plus court
    chemin = reconstitution(pred, dep, arriv)

    return dist[arrivee], chemin

"""
_________________________________

              A*
_________________________________

"""

def Aetoile(dep, arriv,fen):
    n = len(liste_poids)
    depart = indice(dep)
    arrivee = indice(arriv)

    dist = [float('inf')] * n
    pred = [None] * n
    f = [float('inf')] * n
    h = [heuristique(i, arrivee) for i in range(n)]
    atraiter = [i for i in range(n)]

    dist[depart] = 0
    f[depart] = h[depart]

    while atraiter:
        u = extract_min(f, atraiter)
        atraiter.remove(u)

        if u == arrivee:
            break

        for v in atraiter:
                relacher_A(u, v, dist, pred, f, h)
                
                # Trouver les indices des arcs d'arrivée "v" dans le DataFrame aretes
                indices_arc_arrivee_v = aretes.index[aretes['arrivee'] == nomsom(v)].tolist()
                
                
                for ind in indices_arc_arrivee_v:
                    # Récupérer le sommet de départ de l'arc à partir de l'indice trouvé
                    sommet_depart = aretes.loc[ind, 'depart']
            
                    point_debut = Point(sommets.loc[indice(sommet_depart), "x"], sommets.loc[indice(sommet_depart), "y"])
                    point_fin = Point(sommets.loc[v, "x"], sommets.loc[v, "y"])
                    
                    #Tracer l'arc traité
                    arc = fen.create_line(point_debut.x, point_debut.y, point_fin.x, point_fin.y, fill="red", width=2)
            
                    
                # Attendre un court moment
                time.sleep(0.1)
    
                fen.update()

    chemin = reconstitution(pred, dep, arriv)

    return dist[arrivee], chemin
    
# Menu pour permettre à l'utilisateur de choisir une action
if __name__ == "__main__":
    # Dimensions de la fenêtre
    largeur = 1411
    hauteur = 912

    # Définir les actions correspondant à chaque choix
    actions = {
        'D': Dijkstra,
        'B': Bellman,
        'A': Aetoile
    }

    quitter = False  # Indicateur pour quitter le menu
    while not quitter:
        print("")
        # Afficher le menu utilisateur
        print("Menu Utilisateur :")
        print("D - Exécuter Dijkstra")
        print("B - Exécuter Bellman")
        print("A - Exécuter A*")
        print("Q - Quitter")
        print("")

        # Demander le choix à l'utilisateur
        choix = input("Entrez votre choix : ").upper()
        print("")

        if choix in actions:
            
            imgNom = "CaptureOpenStreetMap2024.png"

            # Définir un point d'ancrage pour l'image
            point_ancrage = Point(largeur / 2, hauteur / 2)  # Centre du canvas

            # Créer une instance de la classe Image avec le chemin de l'image
            img = Image(point_ancrage, imgNom)

            # Créer une fenêtre graphique
            fen = GraphWin("Centre-ville de Bayonne", largeur, hauteur)

            # Afficher la carte dans la fenêtre avec les arcs et les points
            img.draw(fen)
               
            # Tracer tous les points sur la fenêtre graphique
            for ind in sommets.index:
                # Obtenir les coordonnées GPS du sommet à l'index donné
                pt = Point(sommets.loc[ind, "x"],sommets.loc[ind, "y"])
                
                # Dessiner le point sur le canevas
                point = fen.create_oval(pt.x - 2, pt.y - 2, pt.x + 2, pt.y + 2, outline="black", fill="black")

            # Définir l'index du DataFrame sur la colonne 'id_point'
            sommets.set_index('id_point', inplace=True)

            # Tracer tous les arcs sur la fenêtre graphique
            for ind in aretes.index:
                
                # Récupérer les points de départ et d'arrivée des arcs
                debut = aretes.loc[ind, 'depart']
                fin = aretes.loc[ind, 'arrivee']
                
                # Obtenir les coordonnées GPS des points de départ et d'arrivée
                point_debut = Point(sommets.loc[debut, "x"],sommets.loc[debut, "y"])
                point_fin = Point(sommets.loc[fin, "x"],sommets.loc[fin, "y"])
                
                arc = fen.create_line(point_debut.x, point_debut.y, point_fin.x, point_fin.y, fill="black")
             
            fen.flush()

            # Réinitialiser l'index du DataFrame sommets pour avoir des indices de 0 à len(sommets)-1
            sommets.reset_index(inplace=True)
            
            # Exécuter l'action correspondante au choix de l'utilisateur
            actions[choix](8947020815,255321840,fen)
            
            
            # Attendre un clic pour fermer la fenêtre
            fen.getMouse()
            fen.close()

            # Sortir de la boucle après l'exécution de l'action
            quitter = True
            
        elif choix == 'Q':
            # Sortir de la boucle pour quitter
            quitter = True
            
        else:
            print("Choix invalide. Veuillez entrer D, B, A ou Q.")
    print("")   
    print("Au revoir !")