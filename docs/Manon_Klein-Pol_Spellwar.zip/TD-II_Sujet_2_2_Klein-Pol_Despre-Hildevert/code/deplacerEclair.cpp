#include "jeu.h"

void deplacerEclair(SpellWar &maPartie, unsigned short int ligne, unsigned short int col)
{
    Coord actuelCoord; // Coordonnées actuelles de l'élément
    Coord nouvCoord;   // Nouvelles coordonnées de l'élément

    //Vérifier que l'élément est un éclair
    if (typeElt(maPartie, ligne, col) == eclair)
    {
        // Augmenter nombre de tour joue
        augmenterTourJoue(maPartie, ligne, col);

        // Initialiser coordonnées de l'entité courante
        actuelCoord = {ligne, col};

        // Initialiser coordonnées de la destination
        nouvCoord = {ligne, static_cast<unsigned short int>(col + 1)};

        // Aller a droite
        deplacer(maPartie, actuelCoord, nouvCoord);
    }
}
