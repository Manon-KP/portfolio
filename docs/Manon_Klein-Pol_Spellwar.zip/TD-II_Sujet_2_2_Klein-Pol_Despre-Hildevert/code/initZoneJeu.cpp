#include "jeu.h"

void initZoneJeu(SpellWar &maPartie)
{
    unsigned short int nbLignes = maPartie.NB_LIGNES;     // nombres de lignes du tableau zoneJeu de maPartie
    unsigned short int nbColonnes = maPartie.NB_COLONNES; // nombres de colonnes du tableau zoneJeu de maPartie
    unsigned short int ligneCourante;                     // numero de la ligne couramment parcouru
    unsigned short int colCourante;                       // numero de la colonne couramment parcouru


    // Placer les entités vide
    for (ligneCourante = 0; ligneCourante < nbLignes; ligneCourante++)
    {
        for (colCourante = 0; colCourante < nbColonnes; colCourante++) 
        {
            maPartie.zoneJeu[ligneCourante][colCourante] = {vide, espace, gris, 0};
        }
    }

    // Faire les murs horizontaux 
    for (colCourante = 0; colCourante < nbColonnes; colCourante++)
    {
        maPartie.zoneJeu[0][colCourante] = {murH, croisillon, blanc, 0};            // Place les murs sur la 1ère ligne
        maPartie.zoneJeu[nbLignes - 1][colCourante] = {murH, croisillon, blanc, 0}; // Place les murs sur la dernière ligne
    }

    // Faire le mur vertical
    for (ligneCourante = 1; ligneCourante < nbLignes - 1; ligneCourante++)
    {
        maPartie.zoneJeu[ligneCourante][0] = {murV, barre, blanc, 0}; // Place le mur vertical sur la premiere colonne
    }
}