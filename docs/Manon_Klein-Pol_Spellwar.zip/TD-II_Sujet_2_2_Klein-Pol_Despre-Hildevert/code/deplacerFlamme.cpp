#include "jeu.h"

void deplacerFlamme(SpellWar &maPartie, unsigned short int ligne, unsigned short int col)
{
    // Vérifier que l'élément est une flamme
    if (typeElt(maPartie, ligne, col) == flamme)
    {
        allerAGauche(maPartie, ligne, col);
    }
}