#include "jeu.h"

void initEntiteJeu(SpellWar &maPartie)
{
    unsigned short int nbLignes = maPartie.NB_LIGNES;     // nombres de lignes du tableau zoneJeu de maPartie
    unsigned short int nbColonnes = maPartie.NB_COLONNES; // nombres de colonnes du tableau zoneJeu de maPartie
    unsigned short int nbArca;                            // nombre d'arcaflammes presents dans maPartie
    unsigned short int nbNecro;                           // nombre de necrogiffes presents dans maPartie
    unsigned short int ligneRandom;                       // numero de ligne genere de facon aleatoire
    bool placementOK;                                     // indique si l'entite est placee à la place d'un vide dans zoneJeu

    Coord coordJ; // coordonnées du joueur

    // Calculer les coordonnées du joueur
    coordJ = {static_cast<unsigned short int>(nbLignes / 2), 1}; 

    // placer J en position coordJ 
    maPartie.zoneJeu[coordJ.ligne][coordJ.col] = {joueur, lettreJ, cyan, 0}; 

    // Générer le nb d'arcaflammes et le nb de necrogriffes
    nbArca = static_cast<unsigned short int>(random(0, maPartie.NB_MONSTRES)); 
    nbNecro = static_cast<unsigned short int>(maPartie.NB_MONSTRES - nbArca);

    // Placer les monstres = MEME PROCEDURE car eviter dupliccation de code, une seule chose change :
    // zoneJeu[ligneRandom][nbColonnes - 1] = {arcaflamme, A, jaune, 0}; ET zoneJeu[ligneRandom][nbColonnes - 1] = {necrogriffe, N, violet, 0};

    // Placer les arcaflammes
    for (unsigned short int nbArcaPlace = 0; nbArcaPlace < nbArca; nbArcaPlace++)
    {
        do
        {
            ligneRandom = static_cast<unsigned short int>(random(1, nbLignes - 1));
            placementOK = (typeElt(maPartie, ligneRandom, static_cast<unsigned short int>(nbColonnes - 1)) == vide); // verifier si les monstres sont places à la place d'un vide

        } while (!placementOK);

        maPartie.zoneJeu[ligneRandom][nbColonnes - 1] = {arcaflamme, lettreA, jaune, 0};
    }

    // Placer les necrogriffes
    for (unsigned short int nbNecroPlace = 0; nbNecroPlace < nbNecro; nbNecroPlace++)
    {
        do
        {
            ligneRandom = static_cast<unsigned short int>(random(1, nbLignes - 1));

            // verifier si les monstres sont placés à la place d'un vide
            placementOK = (typeElt(maPartie, ligneRandom, static_cast<unsigned short int>(nbColonnes - 1)) == vide);

        } while (!placementOK);

        maPartie.zoneJeu[ligneRandom][nbColonnes - 1] = {necrogriffe, lettreN, violet, 0};
    }

}
