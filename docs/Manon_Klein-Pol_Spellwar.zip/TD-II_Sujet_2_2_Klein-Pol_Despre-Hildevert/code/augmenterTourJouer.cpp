#include "jeu.h"

void augmenterTourJoue(SpellWar &maPartie, unsigned short int ligne, unsigned short int col)
{
    maPartie.zoneJeu[ligne][col].nbTourJoue++;
}
