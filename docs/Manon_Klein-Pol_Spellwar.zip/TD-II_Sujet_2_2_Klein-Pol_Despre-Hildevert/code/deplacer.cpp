#include "jeu.h"
void deplacer(SpellWar &maPartie, Coord actuelCoord, Coord nouvCoord)
{
    // Mettre à jour la case de destination avec l'entité
    maPartie.zoneJeu[nouvCoord.ligne][nouvCoord.col] = maPartie.zoneJeu[actuelCoord.ligne][actuelCoord.col];

    // Mettre à jour la case actuelle avec une entité vide
    maPartie.zoneJeu[actuelCoord.ligne][actuelCoord.col] = {vide, espace, gris, 0};
}
