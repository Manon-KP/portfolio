#include "jeu.h"

NomElt typeElt(const SpellWar& maPartie, unsigned short int ligne, unsigned short int col)
{
    return maPartie.zoneJeu[ligne][col].nom;
}