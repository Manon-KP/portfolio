#include "jeu.h"


EtatPartie joueurMeurt(SpellWar &maPartie, unsigned short int ligne, unsigned short int col)
{
    //EtatPartie partie = maPartie.partie; //Etat de la partie

    if (typeElt(maPartie, ligne, col) == flamme || typeElt(maPartie, ligne, col) == necrogriffe )
    {

        maPartie.zoneJeu[ligne][col] = {vide, espace, gris, 0};
        maPartie.partie = perdue;
        
    }

    return maPartie.partie;
}

