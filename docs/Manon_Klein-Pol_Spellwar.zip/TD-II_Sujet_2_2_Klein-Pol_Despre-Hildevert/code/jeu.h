#ifndef JEU_H
#define JEU_H

#include "game-tools.h"
#include <iostream>
using namespace std;

// VARIABLES

// Déclaration du type énumérée ConclusionPartie, indique si la partie est en cours, gagnee, perdue ou abandonee
enum EtatPartie
{
    enCours,
    gagnee,
    perdue,
    abandonnee
};

// Déclaration de l'enregistrement Coord, permet de manipuler des coordonnees
struct Coord
{
    unsigned short int ligne; // numero de la ligne
    unsigned short int col;   // numero de la colonne
};

// Déclaration type énuméré NomElt, nom de chaque element du jeu
enum NomElt
{
    joueur,
    arcaflamme,
    necrogriffe,
    eclair,
    flamme,
    vide,
    murH, // correspond aux murs horizontaux
    murV  // correspond au mur vertical
};
// Déclaration du type énuméré Style, correspond au caractere qui symbolise chaque element du jeu
enum Style
{
    espace = 32,     // Le caractere ' ' a pour code ASCII 32
    croisillon = 35, // Le caractere '#' a pour code ASCII 35
    inferieur = 60,  // Le caractere '<' a pour code ASCII 60
    superieur = 62,  // Le caractere '>' a pour code ASCII 62
    lettreA = 65,    // Le caractere 'A' a pour code ASCII 65
    lettreJ = 74,    // Le caractere 'J'' a pour code ASCII 74
    lettreN = 78,    // Le caractere 'N' a pour code ASCII 78
    barre = 124      // Le caractere '|' a pour code ASCII 124

};

// Déclaration du type énuméré ActionsJoueur, correspond aux actions que peut effectuer le joueur
enum ActionsJoueur
{
    abandon = 97,        // Le caractere 'a' a pour code ASCII 97
    joueurDescend = 100, // Le caractere 'd' a pour code ASCII 100
    lanceEclair = 101,   // Le caractere 'e' a pour code ASCII 101
    joueurMonte = 109    // Le caractere 'm' a pour code ASCII 109

};

// Déclaration du type énuméré ActionsArca, correspond aux actions que peut effectuer un arcaflamme
enum ActionsArca
{
    arcaMonte,
    arcaDescend,
    lanceFlamme

};

// Déclaration du type énuméré ActionsNecro, correspond aux actions que peut effectuer un necrogriffe
enum ActionsNecro
{
    enBasAGauche,
    enHautAGauche,
    gauche

};

// Déclaration de l'enregistrement Entite, informations de chaque element du jeu
struct Entite
{
    NomElt nom;                    // Nom de l'element
    Style style;                   // Correspond au caractere qui symbolise chaque element du jeu
    Couleur coul;                  // Couleur de l'element du jeu, declare dans "game-tools.h"
    unsigned short int nbTourJoue; // Nombre de tours joues par l'element du jeu
};

struct SpellWar
{
    static const unsigned short int NB_LIGNES = 10;   // nombre de lignes du tableau zoneJeu
    static const unsigned short int NB_COLONNES = 10; // nombre de colonnes du tableau zoneJeu
    const unsigned short int NB_MONSTRES = 6;         // nombre de monstres présents dans zoneJeu
    unsigned short int numTourActuel = 1;             // numero du tour actuel
    EtatPartie partie = enCours;                      // etat de la partie

    Entite zoneJeu[NB_LIGNES][NB_COLONNES]; // Tableau, zoneJeu, de dimensions NB_LIGNES NB_COLONNES contenant des elements de type Entite
};

// DECLARATIONS DES PROCEDURES ET FONCTIONS

NomElt typeElt(const SpellWar &maPartie, unsigned short int ligne, unsigned short int col);
// But: Retourne le nom d'une entite present dans maPartie en position ligne, col

void initZoneJeu(SpellWar &maPartie);
//But: Placer les murs horizontaux et le mur vertical dans la zone de jeu de maPartie

void initEntiteJeu(SpellWar &maPartie);
/*Placer les vides, le joueur (sur la gauche au milieu du mur vertical) et les monstres (placés aléatoirement sur la derniere colonne),
dans la zone de jeu de maPartie*/

void afficherActionsPossibles();
// But : Afficher les actions que peut saisir le joueur (abandonner, monter, descendre, eclair)

void afficherZoneJeu(const SpellWar &maPartie);
// But: Afficher le contenu de la zone de jeu de maPartie

void deplacer(SpellWar &maPartie, Coord actuelCoord, Coord nouvCoord);
// But : Deplace le contenu de maPartie des coordonnees ancienCoord aux coordonnees nouvCoord, une entite vide se place aux ancienCoord. N'effectue pas de verifiaction

void monter(SpellWar &maPartie, unsigned short int ligne, unsigned short int col);
// But: Effectuer l'action monter si la case située en ligne-1, col est vide dans la zone de jeu de maPartie

void descendre(SpellWar &maPartie, unsigned short int ligne, unsigned short int col);
// But: Effectuer l'action descendre si la case située en ligne+1, col est vide dans la zone de jeu de maPartie

void allerAGauche(SpellWar &maPartie, unsigned short int ligne, unsigned short int col);
// But: Aller à gauche en ligne col+1 dans la zone de jeu de maPartie

void augmenterTourJoue(SpellWar &maPartie, unsigned short int ligne, unsigned short int col);
// But : Augmenter le nombre de tour joue par un element en position ligne col de maPartie

void tourJoueur(SpellWar &maPartie, string repJ, unsigned short int actionEnCours, unsigned short int ligne, unsigned short int col);
/*But : Effectuer une seule action, repJ en position actionEncours, saisie par le joueur qui est place dans la zone de jeu de 
maPartie en position ligne col.*/

void tourArca(SpellWar &maPartie, unsigned short int ligne, unsigned short int col);
// But : Effectuer une action de facon aleatoire d'un arcaflamme qui est place dans la zone de jeu de maPartie en position ligne col

void tourNecro(SpellWar &maPartie, unsigned short int ligne, unsigned short int col);
// But : Effectuer une action de facon aleatoire d'un necrogriffe qui est place dans la zone de jeu de maPartie en position ligne col

void deplacerFlamme(SpellWar &maPartie, unsigned short int ligne, unsigned short int col);
// But: Deplacer une flamme dans la zone de jeu de maPartie en position ligne col à chaque tour

void deplacerEclair(SpellWar &maPartie, unsigned short int ligne, unsigned short int col);
// But: Deplacer un eclair dans la zone de jeu de maPartie en position ligne col à chaque tour

void effectuerTours(SpellWar &maPartie);
/*But : Effectuer le(s) tour(s) du joueur, des ennemies et deplacer les sorts de maPartie. 
Le nombre de tours effectues depend du nombre d'actions que le joueur a saisi. 
A chaque action effectue par un monstre ou par le joueur ou par un sort, la zone de jeu s'affiche*/ 

void afficherFinPartie(const SpellWar &maPartie);
// But : Afficher le message de fin de la partie selon son etat (abandonnee, gagnee, perdue)

void supprEclair(SpellWar &maPartie, unsigned short int ligne, unsigned short int col);
/* But : Supprimer l'éclair dans la zone de jeu de maPartie en position ligne col s'il rencontre un monstre 
   ou s'il atteint la fin de la zone de jeu*/

void supprFlamme(SpellWar &maPartie, unsigned short int ligne, unsigned short int col);
/* But : Supprimer la flamme dans la zone de jeu de maPartie en position ligne col si elle rencontre un nécrogriffe,
   le joueur ou le mur vertical*/

void arcaMeurt(SpellWar &maPartie, unsigned short int ligne, unsigned short int col);
// But : Faire disparaître l'arcaflamme dans la zone de jeu de maPartie en position ligne col s'il se fait toucher par un éclair 

void necroMeurt(SpellWar &maPartie, unsigned short int ligne, unsigned short int col);
/* But : Faire disparaître le nécrogriffe dans la zone de jeu de maPartie en position ligne col s'il touche un éclair,
   une flamme ou le mur vertical */

EtatPartie joueurMeurt(SpellWar &maPartie, unsigned short int ligne, unsigned short int col);
/* But : Faire disparaître le nécrogriffe dans la zone de jeu de maPartie en position ligne col s'il touche un éclair,
   une flamme ou le mur vertical */

#endif