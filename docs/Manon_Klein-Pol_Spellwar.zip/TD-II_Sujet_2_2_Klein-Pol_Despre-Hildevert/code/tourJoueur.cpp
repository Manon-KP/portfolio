#include "jeu.h"

void tourJoueur(SpellWar &maPartie, string repJ, unsigned short int actionEnCours, unsigned short int ligne, unsigned short int col)
{
    //Verifier si l'element est le joueur
    if (typeElt(maPartie, ligne, col) == joueur)
    {
        // Augmenter nombre de tour joue
        augmenterTourJoue(maPartie, ligne, col);
        
        char action = repJ[actionEnCours]; // Traiter une action du joueur

        // Effectuer action si possible
        switch (action)
        {
        case 'e':
            // Lancer un eclair (un seul a la suite)
            maPartie.zoneJeu[ligne][col + 1] = {eclair, superieur, cyan, maPartie.numTourActuel};

            break;
        case 'm':
            monter(maPartie, ligne, col);
            break;
        case 'd':
            descendre(maPartie, ligne, col);
            break;
        case 'a':
            // Abandonner
            maPartie.partie = abandonnee;

            break;
        }
    }
}