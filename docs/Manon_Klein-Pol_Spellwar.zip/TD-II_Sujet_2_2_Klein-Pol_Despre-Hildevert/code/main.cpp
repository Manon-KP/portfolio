/*
Programme : Spellwar
But :
Auteurs : Manon Klein-Pol TDII TP3 et DESPRE-HILDEVERT TDII TP3
Date de derniere modification : 19/12/2024
Remarques :
Nous certifions être les auteurs de ce code source et attestons ne pas avoir utilisé d'extraits de code provenant d'internet.
Ce code source s'appuie uniquement sur les notions de programmation vues dans le cadre du module R1.01 - Initiation au développement.
*/

#include "jeu.h"
using namespace std;

int main(void)
{
    // VARIABLES
    SpellWar partieEnCours;
    //unsigned short int lignes;
    //unsigned short int cols;

    // APPELS DES SOUS-PROGRAMME

    //Initialiser le zone de jeu
    initZoneJeu(partieEnCours);
    initEntiteJeu(partieEnCours);

    // Jouer tant que la partie est ni abandonnee, ni perdue
    do
    {  
        // Effectuer le(s) tour(s) du joueur, des ennemies et deplacer les sorts

        /*Les appels des sous-programmes de morts ne fonctionnent pas mais les sous-programmes
        fonctionnent donc nous les avons mis en commentaire*/
        
        /*necroMeurt(partieEnCours, lignes, cols);
        arcaMeurt(partieEnCours, lignes, cols);
        supprEclair(partieEnCours, lignes, cols);
        supprFlamme(partieEnCours, lignes, cols);
        joueurMeurt(partieEnCours,lignes, cols );*/
        
        effectuerTours(partieEnCours);

    } while (partieEnCours.partie == enCours);

    // Affichages
    afficherZoneJeu(partieEnCours);
    afficherActionsPossibles();

    // Afficher la fin de partie
    afficherFinPartie(partieEnCours);

    return 0;
}
