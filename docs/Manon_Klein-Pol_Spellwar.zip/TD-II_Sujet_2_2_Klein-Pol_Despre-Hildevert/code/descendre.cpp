#include "jeu.h"

void descendre(SpellWar &maPartie, unsigned short int ligne, unsigned short int col)
{
    Coord actuelCoord; // Coordonnées actuelles de l'élément
    Coord nouvCoord;   // Nouvelles coordonnées de l'élément

    // Initialiser coordonnées de l'entité courante
    actuelCoord = {ligne, col};

    // Descendre s'il n'a pas de mur
    if (typeElt(maPartie, static_cast<unsigned short int>(ligne + 1), col) != murH)
    {
        // Initialiser coordonnées de la destination
        nouvCoord = {static_cast<unsigned short int>(ligne + 1), col};

        // Descendre l'entité
        deplacer(maPartie, actuelCoord, nouvCoord);
    }
}
