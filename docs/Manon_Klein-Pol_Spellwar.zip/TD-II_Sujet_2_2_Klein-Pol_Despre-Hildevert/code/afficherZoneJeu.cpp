#include "jeu.h"

void afficherZoneJeu(const SpellWar &maPartie)
{
    unsigned short int ligneCourante;                     // numero de la ligne couramment parcouru
    unsigned short int colCourante;                       // numero de la colonne couramment parcouru
    unsigned short int nbLignes = maPartie.NB_LIGNES;     // nombres de lignes du tableau zoneJeu de maPartie
    unsigned short int nbColonnes = maPartie.NB_COLONNES; // nombres de colonnes du tableau zoneJeu de maPartie

    // parcourir les lignes
    for (ligneCourante = 0; ligneCourante < nbLignes; ligneCourante++)
    {
        // parcourir les colonnes
        for (colCourante = 0; colCourante < nbColonnes; colCourante++)
        {

            // afficher element en couleur
            afficherTexteEnCouleur(static_cast<char>(maPartie.zoneJeu[ligneCourante][colCourante].style), maPartie.zoneJeu[ligneCourante][colCourante].coul, false);
        }
        // sauter une ligne
        cout << endl;
    }
}
