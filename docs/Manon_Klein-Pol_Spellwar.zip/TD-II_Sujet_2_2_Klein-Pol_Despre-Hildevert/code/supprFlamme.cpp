#include "jeu.h"

void supprFlamme(SpellWar &maPartie, unsigned short int ligne, unsigned short int col)
{
    if (typeElt(maPartie, ligne, col) == eclair || typeElt(maPartie, ligne, col) == joueur || typeElt(maPartie, ligne, col) == necrogriffe)
    {
        maPartie.zoneJeu[ligne][col] = {vide, espace, gris, 0};
    }

    if (typeElt(maPartie, espace, col) == murV)
    {
        afficherTexteEnCouleur('X', rouge, true);
        maPartie.zoneJeu[ligne][col] = {vide, espace, gris, 0};
        maPartie.zoneJeu[ligne][col] = {murV, barre, gris, 1};
        
    }
}
