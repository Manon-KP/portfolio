#include "jeu.h"

void afficherActionsPossibles()
{

cout << "Actions possibles : " << endl;
cout << "a --> abandonner, m --> monter, d --> descendre, e --> eclair" << endl;

cout << "Vos actions : ";

}
