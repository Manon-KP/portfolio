#include "jeu.h"

void tourArca(SpellWar &maPartie, unsigned short int ligne, unsigned short int col)
{
    ActionsArca action; // action effectuee de facon aleatoire

    // Verifier si l'element est un arcaflamme
    if (typeElt(maPartie, ligne, col) == arcaflamme)
    {
        // Augmenter nombre de tour joue
        augmenterTourJoue(maPartie, ligne, col);

        // Generer action aleatoirement
        action = static_cast<ActionsArca>(random(0, 2));

        // Effectuer action si possible
        switch (action)
        {
        case lanceFlamme:
            maPartie.zoneJeu[ligne][col - 1] = {flamme, inferieur, jaune, 0};
            break;
        case arcaMonte:
            // Monter si un monstre n'est pas à côté

            if (typeElt(maPartie, static_cast<unsigned short int>(ligne - 1), col) != arcaflamme &&
                typeElt(maPartie, static_cast<unsigned short int>(ligne - 1), col) != necrogriffe)
            {
                monter(maPartie, ligne, col);
            }
            break;

        case arcaDescend:
            // Descendre si un monstre n'est pas à côté

            if (typeElt(maPartie, static_cast<unsigned short int>(ligne + 1), col) != arcaflamme &&
                typeElt(maPartie, static_cast<unsigned short int>(ligne + 1), col) != necrogriffe)
            {
                descendre(maPartie, ligne, col);
            }
            break;
        }
    }
}