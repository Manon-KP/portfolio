#include "jeu.h"


void arcaMeurt(SpellWar &maPartie, unsigned short int ligne, unsigned short int col)
{
    unsigned short int nbMonstres = maPartie.NB_MONSTRES;// nombres de monstres du tableau zoneJeu de maPartie

    if (typeElt(maPartie, ligne, col) == eclair)
    {
        maPartie.zoneJeu[ligne][col] = {vide, espace, gris, 0};
        nbMonstres--;
    }

}

