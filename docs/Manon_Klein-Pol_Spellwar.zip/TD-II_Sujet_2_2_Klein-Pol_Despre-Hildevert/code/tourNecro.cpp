#include "jeu.h"

void tourNecro(SpellWar &maPartie, unsigned short int ligne, unsigned short int col)
{
    ActionsNecro action; // action affectuee de facon aleatoire
    Coord actuelCoord;   // Coordonnées actuelles de l'élément
    Coord nouvCoord;     // Nouvelles coordonnées de l'élément

    // Verifier si l'element est un arcaflamme
    if (typeElt(maPartie, ligne, col) == necrogriffe)
    {
        // Augmenter nombre de tour joue
        augmenterTourJoue(maPartie, ligne, col);

        // Generer action aleatoirement
        action = static_cast<ActionsNecro>(random(0, 2));

        // Initialiser coordonnées de l'entité courante
        actuelCoord = {ligne, col};

        // Effectuer action si possible
        switch (action)
        {
        case enBasAGauche:
            // Initialiser coordonnées de la destination
            nouvCoord = {static_cast<unsigned short int>(ligne - 1), static_cast<unsigned short int>(col - 1)};

            // Aller en bas a gauche si possible
            if (typeElt(maPartie, nouvCoord.ligne, nouvCoord.col) != murH &&
                typeElt(maPartie, nouvCoord.ligne, nouvCoord.col) != arcaflamme &&
                typeElt(maPartie, nouvCoord.ligne, nouvCoord.col) != necrogriffe)
            {
                deplacer(maPartie, actuelCoord, nouvCoord);
            }
            break;
        case enHautAGauche:
            // Initialiser coordonnées de la destination
            nouvCoord = {static_cast<unsigned short int>(ligne + 1), static_cast<unsigned short int>(col - 1)};

            // Aller en haut a gauche si possible

            if (typeElt(maPartie, nouvCoord.ligne, nouvCoord.col) != murH &&
                typeElt(maPartie, nouvCoord.ligne, nouvCoord.col) != arcaflamme &&
                typeElt(maPartie, nouvCoord.ligne, nouvCoord.col) != necrogriffe)
            {
                deplacer(maPartie, actuelCoord, nouvCoord);
            }
            break;

        case gauche:
        // Aller a gauche si possible
            if (typeElt(maPartie, ligne, col + 1) != murH &&
                typeElt(maPartie, ligne, col + 1) != arcaflamme &&
                typeElt(maPartie, ligne, col + 1) != necrogriffe)
            {
                allerAGauche(maPartie, ligne, col);
            }

            break;
        }
    }
}