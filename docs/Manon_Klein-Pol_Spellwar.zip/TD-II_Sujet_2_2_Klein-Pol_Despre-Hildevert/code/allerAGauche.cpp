#include "jeu.h"

void allerAGauche(SpellWar &maPartie, unsigned short int ligne, unsigned short int col)
{
    Coord actuelCoord; // Coordonnées actuelles de l'élément
    Coord nouvCoord;   // Nouvelles coordonnées de l'élément

    // Initialiser coordonnées de l'entité courante
    actuelCoord = {ligne, col};

    // Initialiser coordonnées de la destination
    nouvCoord = {ligne, static_cast<unsigned short int>(col - 1)};

    // Aller a gauche
    deplacer(maPartie, actuelCoord, nouvCoord);
}