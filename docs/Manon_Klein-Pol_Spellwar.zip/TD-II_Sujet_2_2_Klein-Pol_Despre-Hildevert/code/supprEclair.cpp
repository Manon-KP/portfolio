#include "jeu.h"

void supprEclair(SpellWar &maPartie, unsigned short int ligne, unsigned short int col)
{
    unsigned short int nbColonnes = maPartie.NB_COLONNES; // nombres de colonnes du tableau zoneJeu de maPartie

    if (typeElt(maPartie, ligne, col)==arcaflamme || 
        typeElt(maPartie, ligne, col)==necrogriffe ||
        typeElt(maPartie, ligne, col)==typeElt(maPartie, ligne, nbColonnes))
    {
        maPartie.zoneJeu[ligne][col] = {vide, espace, gris, 0};

    }

    if (typeElt(maPartie, ligne, col) == flamme)
    {
        maPartie.zoneJeu[ligne][col] = {vide, espace, gris, 0};
        maPartie.zoneJeu[ligne][col] = {vide, espace, gris, 0};
    }
    
}

