#include "jeu.h"

void effectuerTours(SpellWar &maPartie)
{
    unsigned short int nbLignes = maPartie.NB_LIGNES;     // nombres de lignes du tableau zoneJeu de maPartie
    unsigned short int nbColonnes = maPartie.NB_COLONNES; // nombres de colonnes du tableau zoneJeu de maPartie
    unsigned short int ligneCourante;                     // numéro de la ligne couramment parcourue
    unsigned short int colCourante;                       // numéro de la colonne couramment parcourue
    string repJ;                                          // Actions saisies par le joueur
    unsigned short int nbActionsSaisies;                  // Nombre d'actions saisies par le joueur
    unsigned short int nbTour;                        // nombre de tours effectués

    // Affichages
    afficherZoneJeu(maPartie);
    afficherActionsPossibles();

    // Saisir reponse du joueur
    cin >> repJ;

    pause(1);
    effacer();

    // Recuperer le nombre d'actions saisies
    nbActionsSaisies = static_cast<short unsigned int>(repJ.size());

    // Effectuer nbActionsSaisies tours
    for (nbTour=0; nbTour < nbActionsSaisies; nbTour++)
    {

        // parcourir les lignes
        for (ligneCourante = 0; ligneCourante < nbLignes; ligneCourante++)
        {
            // parcourir les colonnes
            for (colCourante = 0; colCourante < nbColonnes; colCourante++) // Correction : NB_COLONNES au lieu de NB_LIGNES
            {

                // verifier que ce ne soit pas un vide ou un mur
                if (typeElt(maPartie, ligneCourante, colCourante) != vide &&
                    typeElt(maPartie, ligneCourante, colCourante) != murH &&
                    typeElt(maPartie, ligneCourante, colCourante) != murV)
                {
                    // verifier le nombre de tour joue par l'element
                    if (maPartie.zoneJeu[ligneCourante][colCourante].nbTourJoue < maPartie.numTourActuel)
                    {
                        tourJoueur(maPartie, repJ, nbTour, ligneCourante, colCourante);

                        tourArca(maPartie, ligneCourante, colCourante);
                        tourNecro(maPartie, ligneCourante, colCourante);

                        deplacerFlamme(maPartie, ligneCourante, colCourante);
                        deplacerEclair(maPartie, ligneCourante, colCourante);

                        // Affichages
                        afficherZoneJeu(maPartie);
                        afficherActionsPossibles();

                        pause(1);
                        effacer();
                    }
                }
            }
        }
        // Augmenter le numero du tour
        maPartie.numTourActuel++;
    }
}
