#include "jeu.h"

void afficherFinPartie(const SpellWar &maPartie)
{
    cout << endl;
    cout << endl;

    switch (maPartie.partie)
    {
    case abandonnee:
        cout << "La partie a ete abandonnee." <<endl;
        break;
    case gagnee:
        cout << "La partie a ete gagnee!" <<endl;
        break;
    case perdue:
        cout << "La partie a ete perdue." <<endl;
        break;
    
    }

}